<!DOCTYPE html>
<html lang="es" class="h-full">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ayni Huata - Iniciar sesión</title>
    <link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}">
    <script>
        try {
            const m = localStorage.getItem('huata-theme') || 'sistema';
            document.documentElement.dataset.bsTheme = m === 'oscuro' || m === 'sistema' && matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'
        } catch (e) {}
    </script>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    <style>
        .lg-page{min-height:100dvh;display:grid;grid-template-columns:1.15fr 1fr;background:#F4E9D7}
        .lg-hero{position:relative;overflow:hidden;color:#fff;padding:56px 64px;display:flex;flex-direction:column;justify-content:center;
            background:radial-gradient(1200px 600px at 10% 0%,#2a6fd0 0%,transparent 60%),linear-gradient(160deg,#1052AD 0%,#0b3f88 60%,#08326e 100%)}
        .lg-wave{position:absolute;left:0;right:0;bottom:-1px;width:100%;height:120px;z-index:0}
        .lg-drop{position:absolute;border-radius:50% 50% 50% 50%/60% 60% 40% 40%;background:#ffffff10;filter:blur(.5px)}
        .lg-logo{width:92px;height:92px;border-radius:26px;background:#FFFCF6;display:grid;place-items:center;box-shadow:0 18px 40px #04224d66}
        .lg-logo img{width:74px;height:74px;object-fit:contain}
        .lg-eyebrow{font-size:12px;font-weight:800;letter-spacing:.28em;color:#F4E9D7;margin:28px 0 10px}
        .lg-title{font-size:clamp(34px,4.2vw,54px);font-weight:900;line-height:1.05;letter-spacing:-.02em;margin:0}
        .lg-title span{color:#F4E9D7}
        .lg-lead{max-width:560px;margin-top:18px;font-size:16px;line-height:1.65;color:#dbe7fb}
        .lg-flow{position:relative;z-index:1;max-width:640px;margin-top:34px;padding:22px 24px;border-radius:22px;background:#ffffff12;border:1px solid #ffffff26;backdrop-filter:blur(6px)}
        .lg-flow p{font-size:11px;font-weight:800;letter-spacing:.2em;color:#F4E9D7;margin:0 0 14px}
        .lg-steps{display:flex;flex-wrap:wrap;align-items:center;gap:10px}
        .lg-step{display:inline-flex;align-items:center;gap:8px;padding:9px 14px;border-radius:14px;background:#0a3a7c99;border:1px solid #ffffff2e;font-size:13px;font-weight:700}
        .lg-step i{color:#9be29f}
        .lg-arrow{color:#F4E9D7aa;font-size:13px}
        .lg-side{display:flex;align-items:center;justify-content:center;padding:40px 28px;
            background:radial-gradient(700px 400px at 100% 0%,#fffaf0 0%,transparent 60%),#F4E9D7}
        .lg-card{width:100%;max-width:470px;background:#FFFCF6;border:1px solid #E7D8BF;border-radius:30px;padding:44px 40px;box-shadow:0 30px 70px #6b4f2526,0 2px 0 #fff inset}
        .lg-card .eyebrow{font-size:12px;font-weight:800;letter-spacing:.22em;color:#1052AD}
        .lg-card h2{font-size:32px;font-weight:900;color:#1e2a38;margin:8px 0 6px}
        .lg-card .sub{font-size:14px;color:#6d6352;line-height:1.55}
        .lg-label{display:block;font-size:12px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:#1e2a38;margin-bottom:8px}
        .lg-input{position:relative}
        .lg-input i{position:absolute;left:16px;top:50%;transform:translateY(-50%);color:#9a8b72;font-size:15px}
        .lg-input input{width:100%;height:54px;padding:0 16px 0 46px;border-radius:16px;border:1.5px solid #E7D8BF;background:#fff;font-size:15px;color:#1e2a38;transition:.15s}
        .lg-input input:focus{outline:none;border-color:#1052AD;box-shadow:0 0 0 4px #1052AD1f}
        .lg-btn{width:100%;height:56px;border:0;border-radius:16px;font-size:16px;font-weight:800;color:#fff;cursor:pointer;
            background:linear-gradient(135deg,#2E7D32,#3c9a41);box-shadow:0 12px 26px #2E7D3255;transition:transform .15s,box-shadow .15s}
        .lg-btn:hover{transform:translateY(-1px);box-shadow:0 16px 30px #2E7D3266}
        .lg-error{padding:12px 14px;border-radius:14px;background:#fdecec;border:1px solid #f5c2c2;color:#8a1f1f;font-size:13px}
        .lg-demo{margin-top:22px;border:1.5px dashed #E7D8BF;border-radius:16px;background:#FBF4E8}
        .lg-demo summary{list-style:none;cursor:pointer;padding:12px 16px;font-size:13px;font-weight:700;color:#6d6352;text-align:center}
        .lg-demo summary::-webkit-details-marker{display:none}
        .lg-demo .grid-demo{display:grid;grid-template-columns:1fr 1fr;gap:6px 14px;padding:4px 18px 16px;font-size:12px;color:#6d6352}
        .lg-demo code{font-weight:800;color:#1052AD}
        .lg-foot{margin-top:22px;text-align:center;font-size:12px;color:#9a8b72}
        [data-bs-theme=dark] .lg-side{background:#141c27}
        [data-bs-theme=dark] .lg-card{background:#1c2735;border-color:#2f3d4f}
        [data-bs-theme=dark] .lg-card h2,[data-bs-theme=dark] .lg-label{color:#f1ebe0}
        [data-bs-theme=dark] .lg-input input{background:#141c27;border-color:#2f3d4f;color:#f1ebe0}
        [data-bs-theme=dark] .lg-demo{background:#233041;border-color:#2f3d4f}
        @media(max-width:991px){.lg-page{grid-template-columns:1fr}.lg-hero{padding:40px 24px 120px}.lg-flow{display:none}.lg-side{padding:0 16px 40px;margin-top:-70px;background:transparent;position:relative;z-index:2}.lg-card{padding:32px 24px}}
    </style>
</head>

<body class="antialiased">
    <div class="lg-page">

        {{-- ===== Lado institucional ===== --}}
        <section class="lg-hero">
            <span class="lg-drop" style="width:260px;height:300px;right:-60px;top:-40px"></span>
            <span class="lg-drop" style="width:140px;height:160px;right:22%;bottom:22%"></span>
            <svg class="lg-wave" viewBox="0 0 1200 120" preserveAspectRatio="none" aria-hidden="true">
                <path d="M0,60 C150,110 300,10 450,50 C600,90 750,20 900,55 C1020,82 1110,60 1200,40 L1200,120 L0,120 Z" fill="#F4E9D7" opacity=".35"/>
                <path d="M0,85 C180,120 320,50 520,80 C700,108 860,60 1020,82 C1100,92 1160,88 1200,80 L1200,120 L0,120 Z" fill="#F4E9D7"/>
            </svg>

            <div style="position:relative;z-index:1">
                <div class="lg-logo"><img src="{{ asset('brand/huata-simbolo-vaca.png') }}" alt="Símbolo de Ecolácteos Huata"></div>
                <p class="lg-eyebrow">ECOLÁCTEOS HUATA · PUNO</p>
                <h1 class="lg-title">Ayni <span>Huata</span></h1>
                <p class="lg-lead">
                    Plataforma de la asociación de productores para el acopio de leche en ruta, la verificación en planta,
                    la producción de quesos y derivados, las ventas y el pago justo a cada productor.
                </p>

                <div class="lg-flow">
                    <p>EL RECORRIDO DE LA LECHE</p>
                    <div class="lg-steps">
                        <span class="lg-step"><i class="fa-solid fa-truck-droplet"></i> 1. Acopio 4:30 AM</span>
                        <span class="lg-arrow">→</span>
                        <span class="lg-step"><i class="fa-solid fa-gauge-high"></i> 2. Planta</span>
                        <span class="lg-arrow">→</span>
                        <span class="lg-step"><i class="fa-solid fa-cheese"></i> 3. Producción</span>
                        <span class="lg-arrow">→</span>
                        <span class="lg-step"><i class="fa-solid fa-hand-holding-dollar"></i> 4. Venta y pago</span>
                    </div>
                </div>
            </div>
        </section>

        {{-- ===== Formulario ===== --}}
        <section class="lg-side">
            <div class="lg-card">
                <span class="eyebrow">PORTAL DE ACCESO</span>
                <h2>Iniciar sesión</h2>
                <p class="sub">Ingresa con tu DNI y contraseña. Son los mismos que usas en la app móvil.</p>

                @if($errors->any())
                    <div class="lg-error mt-4">
                        <i class="fa-solid fa-triangle-exclamation"></i>
                        {{ $errors->first() }}
                    </div>
                @endif

                <form action="{{ route('login.post') }}" method="POST" class="mt-6 space-y-5">
                    @csrf
                    <div>
                        <label for="dni" class="lg-label">DNI</label>
                        <div class="lg-input">
                            <i class="fa-regular fa-id-card"></i>
                            <input type="text" id="dni" name="dni" value="{{ old('dni') }}" required autofocus
                                autocomplete="username" inputmode="numeric" maxlength="20" placeholder="Tu número de DNI">
                        </div>
                    </div>

                    <div>
                        <label for="password" class="lg-label">Contraseña</label>
                        <div class="lg-input">
                            <i class="fa-solid fa-lock"></i>
                            <input type="password" id="password" name="password" required
                                autocomplete="current-password" placeholder="Tu contraseña">
                        </div>
                    </div>

                    <button type="submit" class="lg-btn">
                        <i class="fa-solid fa-arrow-right-to-bracket me-2"></i> Ingresar al sistema
                    </button>
                </form>

                @if(app()->environment('local'))
                <details class="lg-demo">
                    <summary><i class="fa-solid fa-flask me-1"></i> Accesos de demostración (clave: <code>password</code>) <i class="fa-solid fa-chevron-down ms-1"></i></summary>
                    <div class="grid-demo">
                        <div>Jefe general: <code>70000001</code></div>
                        <div>Admin: <code>70000002</code></div>
                        <div>Jefe planta: <code>70000003</code></div>
                        <div>Pagos: <code>70000004</code></div>
                        <div>Calidad: <code>70000005</code></div>
                        <div>Ventas: <code>70000006</code></div>
                        <div>Pagador campo: <code>70000007</code></div>
                        <div>Acopiador: <code>71110001</code></div>
                        <div>Productor Z1: <code>40010001</code></div>
                        <div>Productor Z4: <code>40040013</code></div>
                    </div>
                </details>
                @endif

                <p class="lg-foot">Ecolácteos Huata · Productivo y sostenible</p>
            </div>
        </section>
    </div>
</body>

</html>
