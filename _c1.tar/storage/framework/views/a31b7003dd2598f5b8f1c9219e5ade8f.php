<?php $__env->startSection('title', 'Zonas de Huata y Solicitudes'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $puedeVerAsignacion = in_array(Auth::user()->role, ['admin', 'jefe_general']);
    $esAdmin = Auth::user()->role === 'admin';
    $rutasDeHoy = $rutasDeHoy ?? collect();
    $collectors = $collectors ?? collect();
    $totalProductores = $zones->sum(fn ($z) => $z->producers->count());
    $totalLitros = $rutasDeHoy->sum('total_collected_liters');
    $descansan = $collectors->whereNotIn('id', $rutasDeHoy->pluck('collector_id'));
?>

<div class="space-y-6">

    
    <div class="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-4">
        <div>
            <p class="text-[10px] uppercase tracking-[0.2em] font-bold text-slate-400">Distrito de Huata</p>
            <h1 class="text-2xl font-black text-slate-900 mt-1">Zonas de acopio</h1>
            <p class="text-xs text-slate-500 mt-1 max-w-xl">
                Los cuatro sectores del distrito son fijos; la rotación se maneja asignando el acopiador del día.
            </p>
        </div>

        <?php if($esAdmin): ?>
        <button type="button" data-abrir="modalAsignarZona"
            class="self-start lg:self-auto px-5 py-3 rounded-2xl bg-[#0f1713] hover:bg-slate-900 text-[#bef264] font-bold text-[11px] uppercase tracking-wider whitespace-nowrap shadow-sm transition">
            <i class="fa-solid fa-calendar-check mr-1.5"></i> Asignar zona
        </button>
        <?php endif; ?>
    </div>

    
    <div class="grid grid-cols-2 <?php echo e($puedeVerAsignacion ? 'lg:grid-cols-4' : 'lg:grid-cols-2'); ?> gap-4">
        <div class="bg-white rounded-2xl border border-slate-100 p-4">
            <p class="text-[10px] uppercase font-bold tracking-wider text-slate-400">Zonas</p>
            <p class="text-2xl font-black text-slate-900 mt-1"><?php echo e($zones->count()); ?></p>
        </div>
        <div class="bg-white rounded-2xl border border-slate-100 p-4">
            <p class="text-[10px] uppercase font-bold tracking-wider text-slate-400">Productores</p>
            <p class="text-2xl font-black text-slate-900 mt-1"><?php echo e($totalProductores); ?></p>
        </div>
        <?php if($puedeVerAsignacion): ?>
        <div class="bg-white rounded-2xl border border-slate-100 p-4">
            <p class="text-[10px] uppercase font-bold tracking-wider text-slate-400">Asignadas hoy</p>
            <p class="text-2xl font-black text-slate-900 mt-1">
                <?php echo e($rutasDeHoy->count()); ?><span class="text-sm text-slate-400 font-bold"> / <?php echo e($zones->count()); ?></span>
            </p>
        </div>
        <div class="bg-[#0f1713] rounded-2xl p-4">
            <p class="text-[10px] uppercase font-bold tracking-wider text-[#bef264]/70">Litros de hoy</p>
            <p class="text-2xl font-black text-[#bef264] mt-1"><?php echo e(number_format($totalLitros, 2)); ?> L</p>
        </div>
        <?php endif; ?>
    </div>

    
    <?php if($zones->isEmpty()): ?>
        <div class="bg-white rounded-3xl border border-dashed border-slate-200 p-10 text-center text-sm text-slate-400">
            No hay zonas configuradas.
        </div>
    <?php else: ?>
    <div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <?php $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php ($ruta = $rutasDeHoy->firstWhere('zone_id', $zone->id)); ?>
        <div class="bg-white rounded-3xl border border-slate-100 shadow-sm hover:shadow-md transition flex flex-col overflow-hidden">

            
            <div class="p-5 flex-1">
                <div class="flex items-center justify-between">
                    <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold font-mono bg-[#0f1713] text-[#bef264]">
                        <?php echo e($zone->code); ?>

                    </span>
                    <span class="text-[10px] font-mono text-slate-300">#<?php echo e($zone->id); ?></span>
                </div>

                <h3 class="text-base font-black text-slate-900 mt-3"><?php echo e($zone->name); ?></h3>
                <p class="text-xs text-slate-500 mt-1 leading-relaxed"><?php echo e($zone->description); ?></p>

                <div class="mt-4 flex items-center gap-2 text-xs text-slate-600">
                    <i class="fa-solid fa-users text-slate-300"></i>
                    <span><strong class="text-slate-900 font-black"><?php echo e($zone->producers->count()); ?></strong> productores</span>
                </div>
            </div>

            
            <?php if($puedeVerAsignacion): ?>
            <div class="border-t border-slate-100 bg-slate-50/70 p-5">
                <div class="flex items-center justify-between mb-3">
                    <p class="text-[10px] uppercase font-bold tracking-wider text-slate-400">Hoy · <?php echo e($today); ?></p>
                    <?php if($ruta): ?>
                        <span class="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider
                            <?php echo e($ruta->status === 'descargado'
                                ? 'bg-[#bef264]/30 text-[#0f1713] border border-[#bef264]/50'
                                : 'bg-amber-50 text-amber-700 border border-amber-200'); ?>">
                            <?php echo e($ruta->status); ?>

                        </span>
                    <?php else: ?>
                        <span class="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-slate-100 text-slate-500">
                            Sin asignar
                        </span>
                    <?php endif; ?>
                </div>

                <?php if($ruta): ?>
                <dl class="space-y-2 text-xs">
                    <div class="flex justify-between gap-2">
                        <dt class="text-slate-400">Acopiador</dt>
                        <dd class="font-bold text-slate-900 text-right"><?php echo e($ruta->collector?->name ?? '—'); ?></dd>
                    </div>
                    <div class="flex justify-between gap-2">
                        <dt class="text-slate-400">Salida</dt>
                        <dd class="font-mono font-bold text-slate-700"><?php echo e($ruta->start_time ?? '—'); ?></dd>
                    </div>
                    <div class="flex justify-between gap-2">
                        <dt class="text-slate-400">Litros</dt>
                        <dd class="font-extrabold text-[#0f1713]"><?php echo e(number_format($ruta->total_collected_liters, 2)); ?> L</dd>
                    </div>
                </dl>
                <?php else: ?>
                <p class="text-xs text-slate-400">Ningún acopiador cubre esta zona hoy.</p>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>

    
    <?php if($puedeVerAsignacion && $collectors->isNotEmpty()): ?>
    <div class="bg-white rounded-2xl border border-slate-100 p-4 flex flex-wrap items-center gap-2">
        <span class="text-[10px] uppercase font-bold tracking-wider text-slate-400 mr-1">
            <i class="fa-solid fa-mug-hot mr-1"></i> Descansa hoy:
        </span>
        <?php $__empty_1 = true; $__currentLoopData = $descansan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <span class="px-3 py-1 rounded-full bg-slate-100 text-slate-700 text-xs font-semibold"><?php echo e($c->name); ?></span>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <span class="text-xs text-slate-400">Nadie, todos tienen ruta.</span>
        <?php endif; ?>
    </div>
    <?php endif; ?>

</div>

<?php if($esAdmin): ?>

<div id="modalAsignarZona" hidden class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50">
    <div class="bg-white w-full max-w-md rounded-3xl p-6 shadow-xl">
        <div class="flex items-start justify-between mb-4">
            <div>
                <h3 class="text-base font-bold text-slate-900">Asignar acopiador a zona</h3>
                <p class="text-[11px] text-slate-500">La salida del camión es a las 4:30 AM.</p>
            </div>
            <button type="button" data-cerrar class="text-slate-400 hover:text-slate-700 text-lg leading-none">&times;</button>
        </div>

        <?php if($errors->any()): ?>
        <div class="mb-3 p-3 rounded-xl bg-red-50 border border-red-200 text-[11px] text-red-700">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><?php echo e($error); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>

        <form action="<?php echo e(route('acopio.assign')); ?>" method="POST" class="space-y-3 text-xs">
            <?php echo csrf_field(); ?>
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="block text-[10px] uppercase font-bold text-slate-600 mb-1">Fecha de salida</label>
                    <input type="date" name="date" value="<?php echo e(old('date', $today)); ?>" required
                        class="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-semibold text-slate-800 focus:bg-white">
                </div>
                <div>
                    <label class="block text-[10px] uppercase font-bold text-slate-600 mb-1">Hora de salida</label>
                    <input type="time" name="start_time" value="<?php echo e(old('start_time', '04:30')); ?>" required
                        class="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-semibold text-slate-800 focus:bg-white">
                </div>
            </div>
            <div>
                <label class="block text-[10px] uppercase font-bold text-slate-600 mb-1">Zona de Huata</label>
                <select name="zone_id" required
                    class="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-semibold text-slate-800 focus:bg-white">
                    <?php $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($zone->id); ?>" <?php if(old('zone_id') == $zone->id): echo 'selected'; endif; ?>><?php echo e($zone->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <label class="block text-[10px] uppercase font-bold text-slate-600 mb-1">Acopiador responsable</label>
                <select name="collector_id" required
                    class="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-semibold text-slate-800 focus:bg-white">
                    <?php $__currentLoopData = $collectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $collector): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($collector->id); ?>" <?php if(old('collector_id') == $collector->id): echo 'selected'; endif; ?>>
                        <?php echo e($collector->name); ?><?php echo e($collector->phone ? ' ('.$collector->phone.')' : ''); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <span class="text-[10px] text-slate-400 mt-1 block">
                    Un acopiador solo puede tener una ruta por día.
                </span>
            </div>

            <div class="flex gap-2 pt-2">
                <button type="button" data-cerrar class="flex-1 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-[11px] uppercase">Cancelar</button>
                <button type="submit" class="flex-1 bg-[#0f1713] hover:bg-slate-900 text-[#bef264] font-black py-2.5 rounded-xl text-[11px] uppercase tracking-wider">Guardar asignación</button>
            </div>
        </form>
    </div>
</div>

<script>
(function () {
    const modal = document.getElementById('modalAsignarZona');

    document.querySelectorAll('[data-abrir="modalAsignarZona"]').forEach(function (boton) {
        boton.addEventListener('click', function () { modal.hidden = false; });
    });

    modal.querySelectorAll('[data-cerrar]').forEach(function (boton) {
        boton.addEventListener('click', function () { modal.hidden = true; });
    });

    modal.addEventListener('click', function (evento) {
        if (evento.target === modal) { modal.hidden = true; }
    });

    document.addEventListener('keydown', function (evento) {
        if (evento.key === 'Escape') { modal.hidden = true; }
    });

    // Si la asignación fue rechazada, el modal vuelve abierto mostrando el motivo.
    <?php if($errors->any()): ?>
    modal.hidden = false;
    <?php endif; ?>
})();
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\acopio\acopioWeb\resources\views/zonas/index.blade.php ENDPATH**/ ?>