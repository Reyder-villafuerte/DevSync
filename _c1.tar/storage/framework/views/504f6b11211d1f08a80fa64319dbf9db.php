
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['coleccion']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['coleccion']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $paginado = $coleccion instanceof \Illuminate\Contracts\Pagination\Paginator
        || $coleccion instanceof \Illuminate\Contracts\Pagination\LengthAwarePaginator;
?>

<?php if($paginado): ?>
<div class="px-6 py-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
    <span class="text-[11px] text-slate-500">
        <?php if($coleccion->total() > 0): ?>
        Mostrando <strong class="text-slate-700"><?php echo e($coleccion->firstItem()); ?>–<?php echo e($coleccion->lastItem()); ?></strong>
        de <strong class="text-slate-700"><?php echo e($coleccion->total()); ?></strong>
        <?php else: ?>
        Sin resultados
        <?php endif; ?>
    </span>

    <div class="flex items-center gap-2">
        <?php if($coleccion->onFirstPage()): ?>
        <span class="px-3 py-1.5 rounded-lg bg-slate-50 text-slate-300 font-bold text-[10px] uppercase">Anterior</span>
        <?php else: ?>
        <a href="<?php echo e($coleccion->previousPageUrl()); ?>"
            class="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-[10px] uppercase">Anterior</a>
        <?php endif; ?>

        <span class="text-[11px] text-slate-400">
            Página <?php echo e($coleccion->currentPage()); ?> de <?php echo e(max(1, $coleccion->lastPage())); ?>

        </span>

        <?php if($coleccion->hasMorePages()): ?>
        <a href="<?php echo e($coleccion->nextPageUrl()); ?>"
            class="px-3 py-1.5 rounded-lg bg-spark-dark hover:bg-black text-spark-lime font-bold text-[10px] uppercase">Siguiente</a>
        <?php else: ?>
        <span class="px-3 py-1.5 rounded-lg bg-slate-50 text-slate-300 font-bold text-[10px] uppercase">Siguiente</span>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>
<?php /**PATH D:\acopio\acopioWeb\resources\views/components/paginador.blade.php ENDPATH**/ ?>