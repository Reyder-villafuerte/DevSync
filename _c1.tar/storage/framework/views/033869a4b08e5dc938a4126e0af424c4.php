
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'titulo',
    'descripcion' => null,
    'coleccion' => null,
    'vacio' => 'No hay nada que mostrar todavía.',
    'columnas' => 6,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'titulo',
    'descripcion' => null,
    'coleccion' => null,
    'vacio' => 'No hay nada que mostrar todavía.',
    'columnas' => 6,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $paginado = $coleccion instanceof \Illuminate\Contracts\Pagination\Paginator
        || $coleccion instanceof \Illuminate\Contracts\Pagination\LengthAwarePaginator;
?>

<div class="bg-white rounded-3xl border border-slate-200/80 shadow-sm overflow-hidden">

    <div class="p-6 flex flex-col lg:flex-row lg:items-start justify-between gap-4 border-b border-slate-100">
        <div>
            <h2 class="text-base font-bold text-slate-900"><?php echo e($titulo); ?></h2>
            <?php if($descripcion): ?>
            <p class="text-[11px] text-slate-500 mt-1 max-w-2xl leading-relaxed"><?php echo e($descripcion); ?></p>
            <?php endif; ?>
        </div>

        <?php if(isset($acciones)): ?>
        <div class="flex flex-wrap gap-2"><?php echo e($acciones); ?></div>
        <?php endif; ?>
    </div>

    <?php if(isset($filtros)): ?>
    <div class="px-6 py-3 bg-slate-50/60 border-b border-slate-100">
        <?php echo e($filtros); ?>

    </div>
    <?php endif; ?>

    <div class="overflow-x-auto">
        <table class="w-full text-xs">
            <thead>
                <tr class="text-[10px] uppercase text-slate-400 border-b border-slate-100 bg-white">
                    <th class="text-left py-3 px-4 font-bold w-16">ID</th>
                    <?php echo e($encabezados); ?>

                </tr>
            </thead>
            <tbody>
                <?php echo e($slot); ?>


                <?php if($coleccion !== null && count($coleccion) === 0): ?>
                <tr>
                    <td colspan="<?php echo e($columnas + 1); ?>" class="py-8 text-center text-slate-400 italic"><?php echo e($vacio); ?></td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if (isset($component)) { $__componentOriginalad0bba327ff1c83ca31c0226021c02c4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalad0bba327ff1c83ca31c0226021c02c4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.paginador','data' => ['coleccion' => $coleccion]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('paginador'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['coleccion' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($coleccion)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalad0bba327ff1c83ca31c0226021c02c4)): ?>
<?php $attributes = $__attributesOriginalad0bba327ff1c83ca31c0226021c02c4; ?>
<?php unset($__attributesOriginalad0bba327ff1c83ca31c0226021c02c4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalad0bba327ff1c83ca31c0226021c02c4)): ?>
<?php $component = $__componentOriginalad0bba327ff1c83ca31c0226021c02c4; ?>
<?php unset($__componentOriginalad0bba327ff1c83ca31c0226021c02c4); ?>
<?php endif; ?>

</div>
<?php /**PATH D:\acopio\acopioWeb\resources\views/components/tabla.blade.php ENDPATH**/ ?>