<?php $__env->startSection('title', 'Roles'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">

    <?php if (isset($component)) { $__componentOriginalf97d274ec21c4c7928da22944be26299 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf97d274ec21c4c7928da22944be26299 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tabla','data' => ['titulo' => 'Roles','descripcion' => 'Qué hace cada rol y cuánta gente lo tiene. Se asignan al crear o editar a alguien en Usuarios. No se crean roles nuevos desde aquí: cada uno está cableado a los permisos de las pantallas, y uno inventado dejaría a esa persona sin poder entrar a nada.','coleccion' => $roles,'columnas' => 5,'vacio' => 'Ningún rol coincide con el filtro.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('tabla'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['titulo' => 'Roles','descripcion' => 'Qué hace cada rol y cuánta gente lo tiene. Se asignan al crear o editar a alguien en Usuarios. No se crean roles nuevos desde aquí: cada uno está cableado a los permisos de las pantallas, y uno inventado dejaría a esa persona sin poder entrar a nada.','coleccion' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($roles),'columnas' => 5,'vacio' => 'Ningún rol coincide con el filtro.']); ?>

         <?php $__env->slot('acciones', null, []); ?> 
            <a href="<?php echo e(route('admin.usuarios.index')); ?>"
                class="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-[11px] uppercase tracking-wider whitespace-nowrap">
                Ir a Usuarios
            </a>
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('filtros', null, []); ?> 
            <form method="GET" action="<?php echo e(route('admin.roles.index')); ?>" class="flex flex-wrap items-center gap-2">
                <div class="relative">
                    <i class="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-[10px]"></i>
                    <input type="search" name="buscar" value="<?php echo e(request('buscar')); ?>" placeholder="Buscar rol..."
                        class="w-52 pl-8 pr-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-spark-lime">
                </div>
                <select name="estado" class="py-2 px-3 bg-white border border-slate-200 rounded-xl text-xs font-semibold text-slate-800">
                    <option value="">Todos</option>
                    <option value="con_gente" <?php if(request('estado') === 'con_gente'): echo 'selected'; endif; ?>>Con gente asignada</option>
                    <option value="sin_gente" <?php if(request('estado') === 'sin_gente'): echo 'selected'; endif; ?>>Sin nadie</option>
                </select>
                <button type="submit" class="px-4 py-2 rounded-xl bg-slate-900 text-spark-lime font-bold text-[10px] uppercase">Filtrar</button>
                <?php if(request('buscar') || request('estado')): ?>
                <a href="<?php echo e(route('admin.roles.index')); ?>" class="text-[11px] font-bold text-slate-500 underline">Quitar filtros</a>
                <?php endif; ?>
            </form>
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('encabezados', null, []); ?> 
            <th class="text-left py-3 px-4 font-bold">Rol</th>
            <th class="text-left py-3 px-4 font-bold">Qué hace</th>
            <th class="text-right py-3 px-4 font-bold">Personas</th>
            <th class="text-left py-3 px-4 font-bold">Cobra como</th>
            <th class="text-right py-3 px-4 font-bold">Acciones</th>
         <?php $__env->endSlot(); ?>

        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="border-b border-slate-50 hover:bg-slate-50/60 transition">
            <td class="py-3 px-4 font-mono text-[10px] text-slate-400"><?php echo e($rol['clave']); ?></td>
            <td class="py-3 px-4 font-bold text-slate-800"><?php echo e($rol['etiqueta']); ?></td>
            <td class="py-3 px-4 text-slate-500 max-w-md"><?php echo e($rol['descripcion']); ?></td>
            <td class="py-3 px-4 text-right font-black text-slate-800">
                <?php echo e($rol['total']); ?>

                <?php if($rol['total'] !== $rol['activos']): ?>
                <span class="block text-[10px] font-medium text-amber-600"><?php echo e($rol['activos']); ?> activos</span>
                <?php endif; ?>
            </td>
            <td class="py-3 px-4">
                <?php if($rol['tipo_cliente']): ?>
                <span class="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-blue-100 text-blue-900">
                    <?php echo e($rol['tipo_cliente']->name); ?>

                </span>
                <?php else: ?>
                <span class="text-slate-400">—</span>
                <?php endif; ?>
            </td>
            <td class="py-3 px-4 text-right">
                <a href="<?php echo e(route('admin.usuarios.index', ['rol' => $rol['clave']])); ?>"
                    class="px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-[10px] uppercase">
                    Ver quiénes son
                </a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf97d274ec21c4c7928da22944be26299)): ?>
<?php $attributes = $__attributesOriginalf97d274ec21c4c7928da22944be26299; ?>
<?php unset($__attributesOriginalf97d274ec21c4c7928da22944be26299); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf97d274ec21c4c7928da22944be26299)): ?>
<?php $component = $__componentOriginalf97d274ec21c4c7928da22944be26299; ?>
<?php unset($__componentOriginalf97d274ec21c4c7928da22944be26299); ?>
<?php endif; ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\acopio\acopioWeb\resources\views/admin/roles/index.blade.php ENDPATH**/ ?>