package com.example.holamundo

import kotlin.test.Test
import kotlin.test.assertEquals

class SharedLogicIOSTest {

    @Test
    fun example() {
        assertEquals(3, 1 + 2)
    }
}